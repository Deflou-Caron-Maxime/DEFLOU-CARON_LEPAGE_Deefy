<?php

namespace iutnc\deefy\action;
use iutnc\deefy\audio\lists as lst;

class AddPlaylistAction extends Action {
    
    public function __construct(){
        Action::__construct();
    }

    public function execute() : string {
        if (isset($_SESSION['playlist'])){
            echo 'Une playlist existe déjà !';
        } else {
            $_SESSION['playlist'] = new lst\AudioList('Nouvelle playliste');
        }
    }

}