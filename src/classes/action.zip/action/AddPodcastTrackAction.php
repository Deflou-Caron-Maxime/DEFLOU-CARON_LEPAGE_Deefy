<?php

namespace iutnc\deefy\action;
use iutnc\deefy\audio\lists as lst;

class AddPodcastTrackAction extends Action {
    
    public function __construct(){
        Action::__construct();
    }

    public function execute() : string {
        if (!(isset($_SESSION['playlist']))){
            echo 'Aucune playlist n\'existe, on ne peut pas ajouter de musique dans la playlist !';
        } else {
            $_SESSION['playlist']->addTrack($_SESSION['track']);
        }
    }

}