<?php

namespace iutnc\deefy\dispatch;

class Dispatcher {
    private String $action;
    private array $routes;
    public function __construct(){
        if (isset($_GET['action'])){
            $this->action = $_GET['action'];
        } else {
            $this->action = 'default';
        }
        
    }

    public function run() : void {
        if (isset($this->routes[$this->action])) {
			$html = (new ($this->routes[$this->action])())->execute();
			$this->renderPage($html);	
		} else {
			throw new \Exception("Action '{$this->action}' not found");	
		}
    }
            

    public function addRoute(string $action, string $class) : self {
        $this->routes[$action] = $class;
        $this->action = $action;
        return $this;
    }

    private function renderPage(string $html) : void {
        echo "<!DOCTYPE HTML>
        <html lang='fr'>
        <head>
            <title>Deefy</title>
        </head>
        <body>
            $html
        </body>
        </html>";
    }
}